<?php $__env->startSection('content'); ?>

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-sm">
                                        <div class="nk-block-head-content">
											&nbsp;
										</div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="nk-block-title"><?php echo e(!empty($title)?$title:''); ?></h4>
                                            </div>
                                        </div>
                                        <div class="card card-preview">
                                            <form action="<?php echo e(url('winners')); ?>" method="get">
                                                <div class="card-inner">
                                                    <div class="preview-block">
                                                        <div class="row gy-4">
                                                            <div class="col-sm-4">
                                                                <div class="form-group mt-2">
                                                                    <div class="form-control-wrap">
                                                                        <input type="text" name="search_text" value="<?php echo e(request()->get('search_text')); ?>" placeholder="اسم المستخدم - رقم الجوال - الكود" class="form-control">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-2">
                                                                <div class="form-group mt-2">
                                                                    <button type="submit" class="btn btn-primary">بحث</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div class="card-inner">
                                                <div class="table-responsive">
                                                    <table class="table table-orders nowrap nk-tb-list is-separate">
                                                        <a href="<?php if($users->count()>0): ?><?php echo e(route('winners.export')); ?>/?search_text=<?php echo e(request()->search_text); ?> <?php else: ?> javascript:; <?php endif; ?>" <?php if($users->count()<1): ?> onclick="alert('لا يوجد فائزين');" <?php endif; ?> style="float: left"> تصدير <em class="icon ni ni-file-xls"></em></a>
                                                        <thead>
                                                            <tr>
                                                                <th>#</th>
                                                                <th>الاسم</th>
                                                                <th>الجوال</th>
                                                                <th>الكود</th>
                                                                <th>تاريخ الإضافة</th>
                                                                <th>تاريخ الفوز</th>
                                                                <th>الإجراء</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($key+ $users->firstItem()); ?><td>
                                                                <td><?php echo e($user->name); ?></td>
                                                                <td><?php echo e($user->mobile); ?></td>
                                                                <td><?php echo e($user->code); ?></td>
                                                                <td><?php echo e($user->created_at); ?></td>
                                                                <td><?php echo e($user->win_date); ?></td>
                                                                <td class="tb-odr-action">
                                                                    <?php echo $__env->make('admin.winners.buttons.actions', ['id' => $user->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                </td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div><?php echo e($users->links()); ?></div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div> <!-- nk-block -->
                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mohamed Badrey\Desktop\prizes\resources\views/admin/winners/index.blade.php ENDPATH**/ ?>