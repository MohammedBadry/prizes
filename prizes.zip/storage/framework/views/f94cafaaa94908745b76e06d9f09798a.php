  <script>
    // Set the options that I want
    toastr.options = {
      "closeButton": true,
      "newestOnTop": false,
      "progressBar": false,
      "positionClass": "toast-top-left",
      "preventDuplicates": false,
      "onclick": null,
      "showDuration": "300",
      "hideDuration": "300",
      "timeOut": "2000",
      "extendedTimeOut": "2000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }
  </script>

    <?php if(session()->has('error')): ?>
    <script>toastr.error("<?php echo e(session('error')); ?>");</script>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
    <script>toastr.success("<?php echo e(session('success')); ?>");</script>
    <?php endif; ?>

    <?php if(count($errors->all()) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <script>toastr.error("<?php echo e($error); ?>");</script>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php /**PATH C:\Users\Mohamed Badrey\Desktop\prizes\resources\views/admin/layouts/messages.blade.php ENDPATH**/ ?>