<nav class="kayo-nav">
    <div class="dropdown pull-left kayo-dropdown">
        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            مرحبا, <span><?=$_SESSION['name'];?></span>
            <span class="caret"></span>
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
            <li><a href="#" class="open-edit-popUp">زمن السحب</a></li>
            <li><a href="logout.php">تسجيل خروج</a></li>
        </ul>
    </div>
    <a href="#" class="pull-left">
        <img src="images/logo%202.png" alt="">
    </a>
    <span class="slogan">
        <img src="images/slogan_gold.png" alt="">
    </span>
    <a href="#" class="pull-right">
        <img src="images/logo.png" alt="">
    </a>
</nav>
